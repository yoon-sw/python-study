package com.kiswire.fda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FdaApplicationTests {

	@Test
	void contextLoads() {
	}

}
