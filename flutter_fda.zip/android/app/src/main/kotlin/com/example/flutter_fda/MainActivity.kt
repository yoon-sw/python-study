package com.example.flutter_fda

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
